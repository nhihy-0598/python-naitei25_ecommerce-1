setTimeout(() => {
    $(".alert").alert("close");
}, 3000);
